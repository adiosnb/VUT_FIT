#ifndef STATS
#define STATS

#include <simlib.h>

extern Stat throughput_8_hours;
extern Stat throughput_24_hours;
extern Stat year;
extern Histogram queue_of_cars;

#endif // STATS