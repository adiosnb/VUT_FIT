#ifndef PARAMS
#define PARAMS

extern int backup_screw;
extern int store_prediction;
extern int no_errors;
extern int shorter_time;

extern int screw_errors_count;
extern int screw_overheated;
extern int missing_part;

#endif // PARAMS